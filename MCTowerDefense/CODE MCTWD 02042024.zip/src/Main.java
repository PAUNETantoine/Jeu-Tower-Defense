public class Main {
    public static void main(String[] args) {
        Menu menu = new Menu();
    }
}

//NB lignes 2769 -> 19/03/2024