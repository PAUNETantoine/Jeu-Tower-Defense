public class Overworld {

    private int[][] map; //Map storage ( 1 = dirt, 2 = sand/Way, 3 = house, 4 = spawn )

    private Trap[] tabTraps;

    private Mobs[] typesMobs; //Contient tout les mobs utilisables;

    private String name; //World name

    private int wave; //Actual wave

    private int nbMobs; //nbMobs à spawn sur la map

    private int nbDeMobsSpawn;

    private boolean inHouse; //check if player is in the house

    private int time; //Time in sec

    private final int[] spawn = new int[] {6, 0}; // y = 6 x = 0

    private Player player;

    private int size;

    private Interface ihm;

    private Mobs[] tabMobs;

    private Tower[] tabTower;

    private int nbTower;

    private int nbMobsDep;

    private int nbTraps;


    public Overworld(int wave, boolean inHouse, int time)
    {
        this.map = initMap();
        this.name = "OverWorld";
        this.wave = wave;
        this.nbMobs = 0;
        this.inHouse = inHouse;
        this.time = time;
        this.size = 13;
        this.player = new Player(2, this.getSpawn()[1], this.getSpawn()[0], 0);
        this.tabMobs = new Mobs[200];
        this.tabTower = new Tower[200];
        this.tabTraps = new Trap[200];
        this.nbTower = 0;
        this.nbTraps = 0;

        this.typesMobs = new Mobs[] {
                         new Mobs(0, 12, 1, 0, "Zombie", 1),
                         new Mobs(1, 10, 1, 0, "Squelette", 1),
                         new Mobs(2, 11, 1, 0, "Creeper", 2),
                         new Mobs(3, 8, 1.5, 0, "Spider", 2),
                         new Mobs(4, 15, 1.5, 0, "MountedSpider", 5),
                         new Mobs(5, 20, 0.5, 0 , "Slime", 2)
                                                                                                };


        this.nbDeMobsSpawn = 0;
        this.initMap();
    }

    public void addTower(Tower tower)
    {
        this.tabTower[nbTower++] = tower;
    }

    public void addTraps(Trap trap)
    {
        this.tabTraps[nbTraps++] = trap;
    }

    public Trap[] getTabTraps() {
        return tabTraps;
    }

    public Tower[] getTabTower() {
        return tabTower;
    }

    public void setNbDeMobsSpawn(int add)
    {
        this.nbDeMobsSpawn += add;
    }

    public void setWave(int add)
    {
        this.wave += add;
    }

    public int getNbDeMobsSpawn()
    {
        return nbDeMobsSpawn;
    }

    public void setNbMobs(int add)
    {
        this.nbMobs += add;
    }

    public Mobs getMobs(int type)
    {
        return this.typesMobs[type];
    }

    public Mobs[] getTabMobs()
    {
        return this.tabMobs;
    }

    public void initMobs(int wave)
    {
        for(int i = 0 ; i < wave*5 ; i++)
        {
            int type = (int) (Math.random() * 6);
            if(this.getMobs(type).getWaveToSpawn() > wave)
            {
                i--;
            }else
            {
                this.tabMobs[i] = new Mobs(this.getMobs(type));
            }
        }
        nbMobsDep = wave*5;
    }


    private void checkNbMobDead()
    {
        int cpt = 0;
        for( int i = 0 ; i < this.nbDeMobsSpawn ; i++)
        {
            if (this.tabMobs[i].isDead())
            {
                cpt++;
            }
        }
        this.nbMobs = nbMobsDep - cpt;
    }


    private int[][] initMap()
    {
        return this.map = new int[][] {
                                        {0,0,0,0,0,0,0,0,0,0,3,3,3},
                                        {0,0,0,0,0,0,0,0,0,0,3,3,3},
                                        {0,0,0,0,0,0,0,0,0,0,3,3,3},
                                        {0,0,0,0,0,0,0,0,0,0,0,0,0},
                                        {0,0,0,0,0,0,0,0,0,0,0,0,0},
                                        {0,0,0,0,0,0,0,0,0,0,0,0,0},
                                        {4,0,0,0,0,0,0,0,0,0,0,0,0},
                                        {0,0,0,0,0,0,0,0,0,0,0,0,0},
                                        {0,0,0,0,0,0,0,0,0,0,0,0,0},
                                        {0,0,0,0,0,0,0,0,0,0,0,0,0},
                                        {0,0,0,0,0,0,0,0,0,0,0,0,0},
                                        {0,0,0,0,0,0,0,0,0,0,0,0,0},
                                        {0,0,0,0,0,0,0,0,0,0,0,0,0},
                                                                        };
    }


    public String toString()
    {
        String res = "";

        for ( int i = 0 ; i < this.map.length ; i++ )
        {
            for ( int j = 0 ; j < this.map.length ; j++ )
            {
                res += " " + this.map[i][j];
            }
            res += "\n";
        }

        return res;
    }

    public boolean mobOnThesesCoordinates(int x, int y, int dmg)
    {
        for(int i = 0; i < this.nbDeMobsSpawn ; i++)
        {
            if((this.tabMobs[i].getPosMobDeplacementX() < x - 30 && this.tabMobs[i].getPosMobDeplacementX() > x - 70) && (this.tabMobs[i].getPosMobDeplacementY() < y + 20 && this.tabMobs[i].getPosMobDeplacementY() > y - 20) && !this.tabMobs[i].isDead())
            {
                this.tabMobs[i].setHp(-dmg);
                this.checkNbMobDead();

                if(dmg == 0)//Si boule de neige
                {
                    this.tabMobs[i].setState(1); //Effet de ralentissement
                }
                return true;
            }
        }
        return false;
    }


    public boolean mobOnTrap(int x, int y, Mobs mob)
    {
        if( this.getTrapOnThesesCoo(x, y) != null )
        {
            System.out.println("oui");
            Trap tmp = this.getTrapOnThesesCoo(x, y);
            mob.setHp(-tmp.getDmg());
            mob.setState(tmp.getEffect());
            if(tmp.getType() == 8)
            {
                tmp.setHp(-1);
            }
            return true;
        }
        return false;
    }


    public Trap getTrapOnThesesCoo(int x, int y)
    {
        for ( int i = 0 ; i < nbTraps ; i++ )
        {
            if( this.tabTraps[i] == null )
            {
                return null;
            }


            if( this.tabTraps[i].getHp() <= 0 )
            {
                this.setMap(this.tabTraps[i].getX(), this.tabTraps[i].getY()-1, 1); //On remet du sable si jamais le cactus est détruit
                this.tabTraps[i] = null;
                return null;
            }

            if( this.tabTraps[i].getX()*50 == x && this.tabTraps[i].getY() * 50 == y && this.tabTraps[i].getHp() > 0)
            {
                return this.tabTraps[i];
            }

        }
        return null;
    }

    public void setTime(int add)
    {
        this.time += add;
    }

    public int[][] getMap()
    {
        return this.map;
    }

    public void setMap(int x, int y, int type)
    {
        this.map[y][x] = type;
    }

    public void setInHouse(boolean inHouse)
    {
        this.inHouse = inHouse;
    }

    public int getType(int x, int y)
    {
        return this.getMap()[y][x];
    }


    public int[] getSpawn()
    {
        return this.spawn;
    }

    public int getWave()
    {
        return this.wave;
    }

    public boolean isInHouse()
    {
        return inHouse;
    }

    public int getNbMobs()
    {
        return nbMobs;
    }

    public int getTime()
    {
        return time;
    }

    public Player getPlayer()
    {
        return player;
    }

    public String getName()
    {
        return name;
    }
}
