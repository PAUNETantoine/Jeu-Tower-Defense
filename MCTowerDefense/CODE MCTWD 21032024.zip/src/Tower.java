import javax.swing.*;

public class Tower extends Defense{

    private String nom;

    private Overworld world;

    private Interface ihm;

    private char[] dir;
    private String projectileNom;

    public Tower(int type, int x, int y, String nom, int lvl, char[] dir) {
        super(type, x, y, lvl);
        this.nom = nom;
        this.dir = dir;

        if(type == 1)
        {
            this.projectileNom = "snowBall";
        } else if (type == 2)
        {
            this.projectileNom = "egg";
        } else if (type == 3)
        {
            this.projectileNom = "arrow";
        }else{
            this.projectileNom = "fireBall";
        }
    }


    public void shoot()
    {
        for( int i = 0 ; this.dir[i] == 'N' || this.dir[i] == 'O' || this.dir[i] == 'S' || this.dir[i] == 'E' ; i++ )
        {
            System.out.println(this.dir[i]);
            new Projectile(this.dir[i], this.getX(), this.getY(), this.projectileNom);
        }
    }

    public Overworld getWorld() {
        return world;
    }





    //Début de la inher class Projectile


    private class Projectile {
        private char dir;
        private int x;
        private int y;
        private int xArr;
        private int yArr;
        private Thread lancementPrjctl;
        private static final int DELAY = 150;
        private String type;
        private boolean distroyed;


        public Projectile(char dir, int x, int y, String type) {
            this.dir = dir;
            this.x = x;
            this.y = y;
            this.type = type;
            this.distroyed = false;


            switch(dir)
            {
                case 'N' : this.xArr = this.x; this.yArr = 0; break;
                case 'O' : this.xArr = 0; this.yArr = this.y; break;
                case 'S' : this.xArr = this.x; this.yArr = 12*50+80; break;
                case 'E' : this.xArr = 12*50+50; this.yArr = this.y; break;
            }
            

            this.lancementPrjctl = new Thread(run());
        }


        public Runnable run()
        {
            if(this.distroyed)
            {
                System.out.println("Distroyed");
                return null;
            }
                try {
                    while (this.x != xArr && this.y != yArr) {

                        int currentX = this.x;
                        int currentY = this.y;

                        if (currentX < x) {
                            currentX += 5;
                        }

                        if (currentX > x) {
                            currentX -= 5;
                        }

                        if (currentY < y) {
                            currentY += 5;
                        }

                        if (currentY > y) {
                            currentY -= 5;
                        }


                        if (getWorld().mobOnThesesCoordinates(x, y) != null) { //on regarde si le projectile touche un mob.
                            Mobs mob = getWorld().mobOnThesesCoordinates(x, y);
                            mob.setHp((int)-getDmg()); //on enlève au mob un certain nombre d'HP
                            this.distroyed = true;
                            this.lancementPrjctl = null;
                            return null;
                        }

                        ihm.drawProjectile(this.x, this.y, this.type);

                        this.x = currentX;
                        this.y = currentY;

                        Thread.sleep(DELAY); // Attendre le délai défini avant le prochain déplacement
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                return null;
        }

    }

}



