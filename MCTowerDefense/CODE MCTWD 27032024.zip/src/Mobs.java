public class Mobs {

    private int hp;
    private double speed;
    private int type;
    private int state;

    private int waveToSpawn;

    private int posMobDeplacementX;

    private int posMobDeplacementY;

    private String name;

    private char dir;

    private int nbDeplacement;

    public Mobs(int type, int hp, double speed,int state, String name, int waveToSpawn)
    {
        this.waveToSpawn = waveToSpawn;
        this.name = name;
        this.type = type;
        this.hp = hp;
        this.speed = speed;
        this.state = state;
        this.posMobDeplacementX = 0;
        this.posMobDeplacementY = 350;
        this.dir = 'E';
        this.nbDeplacement = 0;
    }

    public Mobs(Mobs mob)
    {
        this.waveToSpawn = mob.getWaveToSpawn();
        this.name = mob.getName();
        this.type = mob.getType();
        this.hp = mob.getHp();
        this.speed = mob.getSpeed();
        this.state = mob.getState();
        this.posMobDeplacementX = mob.getPosMobDeplacementX();
        this.posMobDeplacementY = mob.getPosMobDeplacementY();
        this.dir = mob.getDir();
        this.nbDeplacement = 0;
    }

    public boolean dealDmgToPlayer(Player player) //On regarde si le mob arrive à faire des dmgs au joueur
    {
        if(     (this.getPosMobDeplacementX() > player.getPosX()*50 - 25 && this.getPosMobDeplacementX() < player.getPosX()*50 + 25 &&
                this.getPosMobDeplacementY()-25 < player.getPosY() * 50  + 50 && this.getPosMobDeplacementY()-25 > player.getPosX() * 50 - 50)
                || this.getPosMobDeplacementX() >= 545 && this.getPosMobDeplacementX() <= 600 && this.getPosMobDeplacementY() > 150
                && this.getPosMobDeplacementY() <= 205) //Si il est devant la maison
        {
            if( !this.isDead() )
            {
                this.setHp(-this.getHp()); //Le mob meurt
                return true;
            }
        }
        return false;
    }

    public int getWaveToSpawn() {
        return waveToSpawn;
    }

    public boolean isDead()
    {
        if ( this.getHp() <= 0 )
        {
            return true;
        }
        return false;
    }

    public int getNbDeplacement()
    {
        return nbDeplacement;
    }

    public void setNbDeplacement(int nbDeplacement)
    {
        this.nbDeplacement += nbDeplacement;
    }

    public int getPosMobDeplacementX() {
        return posMobDeplacementX;
    }

    public int getPosMobDeplacementY() {
        return posMobDeplacementY;
    }

    public void setPosMobDeplacementX(int posMobDeplacementX) {
        this.posMobDeplacementX = posMobDeplacementX;
    }

    public void setPosMobDeplacementY(int posMobDeplacementY) {
        this.posMobDeplacementY = posMobDeplacementY;
    }

    public char getDir()
    {
        return dir;
    }

    public void setDir(char dir)
    {
        this.dir = dir;
    }

    public String getNomMob()
    {
        return this.name;
    }

    public String getName()
    {
        return this.name;
    }

    public int getTypeMob(String str)
    {
        return 0;
    }

    public int getHp()
    {
        return this.hp;
    }

    public double getSpeed()
    {
        return this.speed;
    }



    public int getState()
    {
        return this.state;
    }

    public int getType()
    {
        return this.type;
    }

    public void setHp(int hp)
    {
        this.hp += hp;
    }

    public void setSpeed(int speed)
    {
        this.speed = speed;
    }

    public void setState(int state)
    {
        this.state = state;
    }

    public void setType(int type)
    {
        this.type = type;
    }
}