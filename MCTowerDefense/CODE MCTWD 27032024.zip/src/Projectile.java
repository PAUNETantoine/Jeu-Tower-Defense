public class Projectile implements Runnable
{
    private char dir;
    private int x;
    private int y;
    private int xArr;
    private int yArr;
    private static final int DELAY = 70;
    private String type;
    private Tower tower;
    private boolean restart;


    public Projectile(char dir, int x, int y, String type, Tower tower)
    {
        this.tower = tower;
        this.dir = dir;
        this.x = x + 17;
        this.y = y - 50;
        this.type = type;
        this.restart = false;


        switch(dir)
        {
            case 'N' : this.xArr = this.x; this.yArr = 0; break;
            case 'O' : this.xArr = 0; this.yArr = this.y; break;
            case 'S' : this.xArr = this.x; this.yArr = 12*50+80; break;
            case 'E' : this.xArr = 12*50+50; this.yArr = this.y; break;
        }

    }

    public Projectile(Projectile prjct)
    {
        this.tower = prjct.tower;
        this.dir = prjct.dir;
        this.x = tower.getXTower() + 17;
        this.y = tower.getYTower() - 50;
        this.restart = false;

        this.type = prjct.type;



        switch(dir)
        {
            case 'N' : this.xArr = this.x; this.yArr = 0; break;
            case 'O' : this.xArr = 0; this.yArr = this.y; break;
            case 'S' : this.xArr = this.x; this.yArr = 12*50+80; break;
            case 'E' : this.xArr = 12*50+50; this.yArr = this.y; break;
        }
    }

    public boolean isRestart()
    {
        return restart;
    }

    @Override
    public void run()
    {

        try {
            int xDep = this.x;
            int yDep = this.y;

            while (!this.restart)
            {
                if(this.x >= xDep + 100 || this.y >= yDep + 100 || this.x <= xDep - 100 || this.y <= yDep - 100)
                {
                    this.restart = true;
                    return;
                }

                this.restart = tower.getWorld().mobOnThesesCoordinates(x, y, (int) tower.getDmg());

                if (this.restart)
                {
                    this.x = 2000;
                    this.y = 2000;
                    return;
                }



                int currentX = this.x;
                int currentY = this.y;


                if (currentX < this.xArr) {
                    currentX += 5;
                }

                if (currentX > this.xArr) {
                    currentX -= 5;
                }

                if (currentY < this.yArr) {
                    currentY += 5;
                }

                if (currentY > this.yArr) {
                    currentY -= 5;
                }

                this.x = currentX;
                this.y = currentY;
                tower.setxPrjct(currentX);
                tower.setyPrjct(currentY);

                Thread.sleep(DELAY); // Attendre le délai défini avant le prochain déplacement
            }
        } catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        this.restart = true;
    }


}
