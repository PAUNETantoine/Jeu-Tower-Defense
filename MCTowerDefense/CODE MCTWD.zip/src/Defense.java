public class Defense {
    protected int dmg;
    protected int type;
    protected int lvl;
    protected int x;
    protected int y;
    protected String nom;

    public Defense(int dmg, int type, int lvl, int x, int y)
    {

    }


}
