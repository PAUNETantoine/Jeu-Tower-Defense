public class Tower extends Defense{

}
